from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout


class StatCard(BoxLayout):
    value = StringProperty("0")
    label = StringProperty("")
