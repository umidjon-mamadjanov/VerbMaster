from pathlib import Path

from kivy.properties import StringProperty, NumericProperty
from kivy.uix.label import Label


class Icon(Label):
    """Font Awesome 7 Solid icon widget with safe Unicode fallback."""

    icon = StringProperty("")
    icon_size = NumericProperty(18)

    ICONS = {
        "house": 0xF015,
        "play": 0xF04B,
        "chart": 0xF201,
        "gear": 0xF013,
        "arrow-left": 0xF060,
        "arrow-right": 0xF061,
        "check": 0xF00C,
        "xmark": 0xF00D,
        "book": 0xF02D,
    }

    FALLBACKS = {
        "house": "⌂",
        "play": "▶",
        "chart": "▥",
        "gear": "⚙",
        "arrow-left": "‹",
        "arrow-right": "→",
        "check": "✓",
        "xmark": "×",
        "book": "▣",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.halign = "center"
        self.valign = "middle"
        self.text_size = self.size
        self._has_font = False
        self.bind(size=self._sync_text_size)
        self.bind(icon=self._update_icon)
        self.bind(icon_size=self._update_size)
        self._load_font()
        self._update_icon()
        self._update_size()

    def _sync_text_size(self, *_):
        self.text_size = self.size

    def _load_font(self):
        base = Path(__file__).resolve().parent.parent / "assets" / "fonts"
        candidates = (
            base / "Font Awesome 7 Free-Solid-900.otf",
            base / "Font Awesome 7 Free-Solid-900.ttf",
            base / "FontAwesome.ttf",
            base / "fa-solid-900.ttf",
        )
        for path in candidates:
            if path.exists():
                self.font_name = str(path)
                self._has_font = True
                return

    def _update_icon(self, *_):
        codepoint = self.ICONS.get(self.icon)
        if self._has_font and codepoint:
            self.text = chr(codepoint)
        else:
            self.text = self.FALLBACKS.get(self.icon, "")

    def _update_size(self, *_):
        self.font_size = self.icon_size
