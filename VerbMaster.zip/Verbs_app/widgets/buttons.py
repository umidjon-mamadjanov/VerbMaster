from kivy.properties import (
    StringProperty,
    NumericProperty,
    ListProperty,
)
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.graphics import Color, RoundedRectangle

from widgets.icons import Icon


class PrimaryButton(Button):
    pass


class SecondaryButton(Button):
    pass


class IconTextButton(ButtonBehavior, BoxLayout):
    """
    Custom button with Font Awesome icon + text.

    Designed to avoid the Kivy 2.3.1 Android
    Label.options initialization problem.
    """

    caption = StringProperty("")
    icon = StringProperty("")
    icon_position = StringProperty("left")

    icon_size = NumericProperty(17)
    spacing = NumericProperty(8)

    # Compatible with normal Button-style KV syntax.
    font_size = NumericProperty(14)
    color = ListProperty([1, 1, 1, 1])
    background_color = ListProperty([0, 0, 0, 0])

    radius = NumericProperty(14)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.orientation = "horizontal"
        self.size_hint_y = 1

        # Background
        with self.canvas.before:
            self._bg_color = Color(
                rgba=self.background_color
            )
            self._background = RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[
                    (self.radius, self.radius),
                    (self.radius, self.radius),
                    (self.radius, self.radius),
                    (self.radius, self.radius),
                ],
            )

        self.bind(
            pos=self._update_background,
            size=self._update_background,
            background_color=self._update_background,
            radius=self._update_background,
        )

        # Icon
        self._icon = Icon(
            icon="",
            icon_size=self.icon_size,
            size_hint_x=None,
            width=self.icon_size + 8,
        )

        # Label is intentionally created with minimal properties.
        # This avoids the Label.options problem.
        self._label = Label(
            text="",
            halign="center",
            valign="middle",
            size_hint_x=1,
            size_hint_y=1,
        )

        self.add_widget(self._icon)
        self.add_widget(self._label)

        # Property bindings
        self.bind(
            caption=self._update_content,
            icon=self._update_content,
            icon_position=self._update_content,
            icon_size=self._update_content,
            spacing=self._update_content,
            font_size=self._update_content,
            color=self._update_content,
        )

        self._update_content()

    def _update_background(self, *_):
        self._bg_color.rgba = self.background_color
        self._background.pos = self.pos
        self._background.size = self.size
        self._background.radius = [
            (self.radius, self.radius),
            (self.radius, self.radius),
            (self.radius, self.radius),
            (self.radius, self.radius),
        ]

    def _update_content(self, *_):
        self._label.text = self.caption
        self._label.font_size = self.font_size
        self._label.color = self.color

        self._icon.icon = self.icon
        self._icon.icon_size = self.icon_size
        self._icon.width = self.icon_size + 8

        self.clear_widgets()

        if self.icon_position == "right":
            self.add_widget(self._label)
            self.add_widget(self._icon)
        else:
            self.add_widget(self._icon)
            self.add_widget(self._label)