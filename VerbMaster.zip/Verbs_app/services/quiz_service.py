from copy import deepcopy
from random import choice

from core.constants import DIRECTIONS, SOURCE_KEYS, QUESTION_COUNT
from core.utils import normalize_answer, split_answers
from data.models import AnswerResult, QuizQuestion, QuizResult


class QuizService:
    """Quiz domain logic. No Kivy/UI dependencies."""

    def __init__(self, verbs):
        self.verbs = verbs

    def create_questions(self, count=QUESTION_COUNT):
        pool = deepcopy(self.verbs)
        questions = []

        while pool and len(questions) < count:
            key = choice(list(pool.keys()))
            verb = pool.pop(key)

            source, target = choice(DIRECTIONS)

            source_key = SOURCE_KEYS[source]
            target_key = SOURCE_KEYS[target]

            target_value = str(verb[target_key])

            questions.append(
                QuizQuestion(
                    word=str(verb[source_key]),
                    ask_type=f"Write the {target}",
                    correct_answers=tuple(
                        split_answers(target_value)
                    ),
                )
            )

        return questions

    @staticmethod
    def check_answer(question: QuizQuestion, user_answer: str):
        normalized = normalize_answer(user_answer)

        if not normalized:
            return AnswerResult(
                correct=False,
                user_answer="",
                correct_answer="/".join(question.correct_answers),
                feedback="Please enter an answer.",
            )

        correct = normalized in question.correct_answers

        if correct:
            return AnswerResult(
                correct=True,
                user_answer=user_answer,
                correct_answer="/".join(question.correct_answers),
                feedback="Correct!",
            )

        return AnswerResult(
            correct=False,
            user_answer=user_answer,
            correct_answer="/".join(question.correct_answers),
            feedback="Correct answer: "
                     + "/".join(question.correct_answers),
        )

    @staticmethod
    def build_result(correct: int, incorrect: int):
        total = correct + incorrect
        score = round((correct / total) * 100) if total else 0

        return QuizResult(
            correct=correct,
            incorrect=incorrect,
            score=score,
            total=total,
        )
