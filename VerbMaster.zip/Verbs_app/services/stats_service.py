from data.models import Stats


class StatsService:
    """Business logic related to progress/statistics."""

    def __init__(self, repository):
        self.repository = repository
        self.stats = self.repository.load()

    def record_quiz(self, score: int) -> None:
        self.stats.quizzes += 1
        self.stats.total_score += score

        if score > self.stats.best_score:
            self.stats.best_score = score

        self.repository.save(self.stats)

    def get_summary(self):
        average = (
            round(self.stats.total_score / self.stats.quizzes)
            if self.stats.quizzes
            else 0
        )

        return {
            "quizzes": self.stats.quizzes,
            "best_score": self.stats.best_score,
            "average_score": average,
        }
