Font Awesome 7 Free Solid font included. The app loads: Font Awesome 7 Free-Solid-900.otf
