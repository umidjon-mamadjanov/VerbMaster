class Theme:
    """Centralized visual tokens."""

    BACKGROUND = (0.025, 0.027, 0.035, 1)
    SURFACE = (0.065, 0.072, 0.095, 1)
    SURFACE_2 = (0.085, 0.092, 0.120, 1)

    PRIMARY = (0.20, 0.48, 0.95, 1)
    PRIMARY_DARK = (0.14, 0.34, 0.72, 1)

    TEXT = (0.96, 0.97, 1.0, 1)
    TEXT_SECONDARY = (0.58, 0.61, 0.69, 1)
    TEXT_MUTED = (0.40, 0.43, 0.50, 1)

    SUCCESS = (0.28, 0.82, 0.52, 1)
    ERROR = (0.95, 0.34, 0.38, 1)
    WARNING = (1.0, 0.65, 0.24, 1)

    BORDER = (0.13, 0.15, 0.19, 1)

    RADIUS = 18
