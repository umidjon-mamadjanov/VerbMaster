APP_NAME = "VerbMaster"
QUESTION_COUNT = 15

DIRECTIONS = (
    ("Infinitive", "Past Simple"),
    ("Infinitive", "Past Participle"),
    ("Past Simple", "Infinitive"),
    ("Past Simple", "Past Participle"),
    ("Past Participle", "Infinitive"),
    ("Past Participle", "Past Simple"),
)

SOURCE_KEYS = {
    "Infinitive": "infinitive",
    "Past Simple": "past_simple",
    "Past Participle": "past_participle",
}
