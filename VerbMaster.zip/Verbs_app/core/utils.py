def normalize_answer(value: str) -> str:
    return " ".join(value.strip().lower().split())


def split_answers(value: str):
    return [
        normalize_answer(item)
        for item in value.replace(",", "/").split("/")
        if normalize_answer(item)
    ]
