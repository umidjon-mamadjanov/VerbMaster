from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class QuizQuestion:
    word: str
    ask_type: str
    correct_answers: Tuple[str, ...]


@dataclass(frozen=True)
class AnswerResult:
    correct: bool
    user_answer: str
    correct_answer: str
    feedback: str


@dataclass(frozen=True)
class QuizResult:
    correct: int
    incorrect: int
    score: int
    total: int


@dataclass
class Stats:
    quizzes: int = 0
    best_score: int = 0
    total_score: int = 0
