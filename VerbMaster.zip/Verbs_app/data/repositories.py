import json
from pathlib import Path

from data.models import Stats


class StatsRepository:
    """Persistence abstraction."""

    def load(self) -> Stats:
        raise NotImplementedError

    def save(self, stats: Stats) -> None:
        raise NotImplementedError


class JsonStatsRepository(StatsRepository):
    def __init__(self, storage_dir):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self.file_path = self.storage_dir / "stats.json"

    def load(self) -> Stats:
        if not self.file_path.exists():
            return Stats()

        try:
            data = json.loads(
                self.file_path.read_text(encoding="utf-8")
            )
            return Stats(
                quizzes=int(data.get("quizzes", 0)),
                best_score=int(data.get("best_score", 0)),
                total_score=int(data.get("total_score", 0)),
            )
        except (OSError, ValueError, TypeError):
            return Stats()

    def save(self, stats: Stats) -> None:
        payload = {
            "quizzes": stats.quizzes,
            "best_score": stats.best_score,
            "total_score": stats.total_score,
        }

        temp_path = self.file_path.with_suffix(".tmp")
        temp_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        temp_path.replace(self.file_path)
