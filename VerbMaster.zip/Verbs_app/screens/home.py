from kivy.properties import NumericProperty

from kivy.uix.screenmanager import Screen


class HomeScreen(Screen):
    verb_count = NumericProperty(0)
    quizzes = NumericProperty(0)
    best_score = NumericProperty(0)

    def __init__(self, verb_count, stats_service, **kwargs):
        super().__init__(**kwargs)
        self.verb_count = verb_count
        self.stats_service = stats_service

    def set_stats(self, stats):
        self.quizzes = stats["quizzes"]
        self.best_score = stats["best_score"]
