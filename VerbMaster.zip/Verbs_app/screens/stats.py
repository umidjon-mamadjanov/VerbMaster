from kivy.properties import NumericProperty
from kivy.uix.screenmanager import Screen


class StatsScreen(Screen):
    quizzes = NumericProperty(0)
    best_score = NumericProperty(0)
    average_score = NumericProperty(0)

    def __init__(self, stats_service, on_home, on_practice, **kwargs):
        super().__init__(**kwargs)
        self.stats_service = stats_service
        self.on_home = on_home
        self.on_practice = on_practice

    def set_stats(self, stats):
        self.quizzes = stats["quizzes"]
        self.best_score = stats["best_score"]
        self.average_score = stats["average_score"]

    def home(self):
        self.on_home()

    def practice(self):
        self.on_practice()
