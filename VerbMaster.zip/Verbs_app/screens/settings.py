from kivy.properties import NumericProperty, ListProperty
from kivy.uix.screenmanager import Screen


class SettingsScreen(Screen):
    question_count = NumericProperty(15)
    question_options = ListProperty([5, 10, 15, 20, 30])

    def __init__(self, on_home=None, on_questions_changed=None, **kwargs):
        super().__init__(**kwargs)

        self._on_home = on_home
        self._on_questions_changed = on_questions_changed

    def set_question_count(self, count):
        count = int(count)

        if count not in self.question_options:
            count = 15

        self.question_count = count

        if self._on_questions_changed:
            self._on_questions_changed(count)

    def home(self):
        if self._on_home:
            self._on_home()