from kivy.properties import NumericProperty, StringProperty
from kivy.uix.screenmanager import Screen


class ResultScreen(Screen):
    score_text = StringProperty("0%")
    result_message = StringProperty("")
    correct = NumericProperty(0)
    incorrect = NumericProperty(0)

    def __init__(self, on_home, on_retry, **kwargs):
        super().__init__(**kwargs)
        self.on_home = on_home
        self.on_retry = on_retry

    def set_result(self, result):
        self.correct = result.correct
        self.incorrect = result.incorrect
        self.score_text = f"{result.score}%"

        if result.score >= 90:
            self.result_message = "Excellent work!"
        elif result.score >= 70:
            self.result_message = "Good job!"
        elif result.score >= 50:
            self.result_message = "Keep practicing!"
        else:
            self.result_message = "More practice will help."

        app = self.manager.parent if False else None

    def home(self):
        self.on_home()

    def retry(self):
        self.on_retry()
