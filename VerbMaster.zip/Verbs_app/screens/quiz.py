from kivy.clock import Clock
from kivy.properties import (
    NumericProperty,
    StringProperty,
    ListProperty,
)
from kivy.uix.screenmanager import Screen

from core.theme import Theme


class QuizScreen(Screen):
    question_number = NumericProperty(1)
    question_count = NumericProperty(15)

    show_word = StringProperty("")
    ask_type = StringProperty("")
    feedback = StringProperty("")
    button_text = StringProperty("CHECK")

    feedback_color = ListProperty(Theme.TEXT_SECONDARY)

    def __init__(self, quiz_service, on_finished, **kwargs):
        super().__init__(**kwargs)

        self.quiz_service = quiz_service
        self.on_finished = on_finished

        self.questions = []
        self.current_question = None

        self.correct_count = 0
        self.incorrect_count = 0

        self.answered = False

    def set_question_count(self, count):
        count = int(count)

        if count < 1:
            count = 15

        self.question_count = count

    def start_quiz(self):
        self.questions = self.quiz_service.create_questions(
            self.question_count
        )

        self.question_number = 1
        self.correct_count = 0
        self.incorrect_count = 0
        self.answered = False

        self._load_current_question()

    def _load_current_question(self):
        index = self.question_number - 1

        if index >= len(self.questions):
            self.finish_quiz()
            return

        self.current_question = self.questions[index]

        self.show_word = self.current_question.word
        self.ask_type = self.current_question.ask_type

        self.feedback = ""
        self.button_text = "CHECK"
        self.feedback_color = list(Theme.TEXT_SECONDARY)

        self.answered = False

        if "answer_input" in self.ids:
            self.ids.answer_input.text = ""

            Clock.schedule_once(
                lambda dt: self._focus_input(),
                0.08,
            )

    def _focus_input(self):
        if "answer_input" in self.ids:
            self.ids.answer_input.focus = True

    def check_answer(self):
        if self.answered or not self.current_question:
            return

        answer = self.ids.answer_input.text

        result = self.quiz_service.check_answer(
            self.current_question,
            answer,
        )

        self.feedback = result.feedback

        if not answer.strip():
            self.feedback_color = list(Theme.WARNING)
            return

        if result.correct:
            self.correct_count += 1
            self.feedback_color = list(Theme.SUCCESS)
        else:
            self.incorrect_count += 1
            self.feedback_color = list(Theme.ERROR)

        self.answered = True

        self.button_text = (
            "FINISH"
            if self.question_number >= self.question_count
            else "NEXT"
        )

    def handle_button(self):
        if not self.answered:
            self.check_answer()
            return

        if self.question_number >= self.question_count:
            self.finish_quiz()
        else:
            self.question_number += 1
            self._load_current_question()

    def finish_quiz(self):
        result = self.quiz_service.build_result(
            self.correct_count,
            self.incorrect_count,
        )

        self.on_finished(result)